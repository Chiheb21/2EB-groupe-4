<?php
$servername ('localhost');
$username('root');
$password('');
$database('ds2');
$conn=mysqli_connect($servername,$username,$password,$database);
if($conn==false){
    die("erreur:impossible de se connecter" .mysqli_connect_error());}
$name=$_POST['nom'];
$pren=$_POST['prenom'];
$mail=$_POST['mail'];
$tel=$_POST['tel'];
$dt=$_POST['date'];
$ville=$_POST['ville'];
$sprt=$_POST['sport'];
$hobbies=$_POST['hobbies'];
$langue=$_POST['langue'];
$cer=$_POST['certification'];
$nb=$_POST['mois'];
$pri=$_POST['primaire'];
$sec=$_POST['secondaire'];
$uni=$_POST['universite'];
$req="INSERT INTO information (email, tel, nom, prenom, location, dat, sport, hobbies, langues, certification, mois, grae) VALUES 
('$mail','$tel','$name','$pren','$ville','$dt','$sprt','$hobbies','$langue','$cer','$nb','$pri','$sec','$uni');";
$res=mysqli_query($conn,$req);
if($res){
    echo "<div>
    <h3>
    vous etes inscrit avec succees.</h3>
   </div>"}
   else echo 'requete non executee';
   ?>






	
			
		




