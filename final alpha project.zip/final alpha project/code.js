function a(){ 
    if(f.login.length!=0){
    f.password.disabled=false; 
    }
} 
function b(){ 
    if(f.password.length!=0){
    f.confirmer.disabled=false; 
    }
}
function c(){
    if((f.login.value=="admin")&&(f.password.value=="admin")) {
        alert ('succes');}
        else{
        alert ('erreur');}
    }
