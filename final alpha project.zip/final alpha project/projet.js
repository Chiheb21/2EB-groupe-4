function vide()
{
   if(f2.certification.value!="")
   {
    f2.mois.disabled=false;
   }
}
function telephone()
{
  if(f1.tel.value.length!=8)
 {
 exp=/[^0-9]/;
  if(f1.tel.value!=exp)
  f1.tel.value=f1.tel.value.replace(exp,""); 
}}




function test()
{
  if (f1.nom.value=="" || f1.prénom.value=="" || f1.ville.value==""  || f1.date.value=="")
 alert("IL FAUT REMPLIR LES CHAMPS");
 
}
function checked()
{
  f4.femme.disabled=true;
}